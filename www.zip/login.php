<?php
session_start();
include "header.php";
include "div.php";
echo phpinfo();
include "footer.php";
?>