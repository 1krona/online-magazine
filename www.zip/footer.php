<div id="footer">

<p>Folketstidning.se &copy 2012, administerat under Dojob AB</p>

</div>

</body>

</html>